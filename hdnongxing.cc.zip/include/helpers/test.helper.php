<?php  if(!defined('DEDEINC')) exit('dedecms');
/**
 * 仅用于测试
 *
 * @version        $Id: test.helper.php 5 15:01 2010年7月5日Z tianya $
 * @package        DedeCMS.Helpers
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

//邮箱格式检查
if ( ! function_exists('HelloDede'))
{
    function HelloDede()
    {
        echo "Hello! Dede...";
    }
}